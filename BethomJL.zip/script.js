const menu-icon = document.getElementById('menu-icon')
const menu = document.getElementById('menu')

menu-icon .addEvenlistener('click' , () => {
    nav.style.display = 'block'
});